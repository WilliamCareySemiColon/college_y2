package designPatterns.composite;
 
public interface Shape {
     
    public void draw(String fillColor);
}
