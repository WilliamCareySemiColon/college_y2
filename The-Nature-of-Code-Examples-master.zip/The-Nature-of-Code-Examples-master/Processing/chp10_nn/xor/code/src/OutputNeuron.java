package nn;

public class OutputNeuron extends Neuron {
    public OutputNeuron() {
        super();
    }
}
